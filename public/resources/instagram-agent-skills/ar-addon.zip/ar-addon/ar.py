#!/usr/bin/env python3
"""ar.py — run the Instagram Agent Skills' Python tools on Arabic text (GAOBA AI add-on, MIT).

Why: the tools in instagram-agent-skill count words with a Latin-only pattern ([A-Za-z...]), so an Arabic
script reads as ~0 words and its timing, length and hook checks come out wrong. This add-on loads a tool
UNCHANGED, swaps only its word pattern (and the caption tool's hashtag pattern) for Unicode ones that keep
Arabic letters and their diacritics (shadda, harakat) in one word, then runs the tool's own main().

Usage (from anywhere):
    python ar.py ig-reel/beats.py script.txt --wpm 138 --target 55
    python ar.py ig-caption/caption.py caption.txt
    python ar.py ig-human/detect.py draft.txt
Tools are looked up in $IG_SKILLS, else ~/.claude/skills. An absolute path to a tool also works.
--wpm: your speaking rate in words per minute (Arabic voiceover ~130-145; GAOBA Voice = 138).
Timing is an estimate from the text's word count; nothing listens to audio.

Limits (said honestly): hookscore.py's STAKES and ADDRESS checks and humanize.py's stock-word list are
English word lists; this add-on does not translate them. Score Arabic hooks on an English gloss.
"""
import importlib.util
import os
import re
import sys

ARABIC_MARKS = "\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640"   # diacritics + tatweel
WORD_RE = re.compile(r"[\w" + ARABIC_MARKS + r"$%'’-]+")
HASHTAG_RE = re.compile(r"(?:^|\s)(#[\w" + ARABIC_MARKS + r"]+)")


def main():
    for stream in (sys.stdout, sys.stderr):              # Windows consoles default to cp1252
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__)
        return 0
    rel = sys.argv[1]
    base = os.environ.get("IG_SKILLS") or os.path.join(os.path.expanduser("~"), ".claude", "skills")
    path = rel if os.path.isabs(rel) else os.path.join(base, rel)
    if not os.path.isfile(path):
        print(f"ar.py: tool not found: {path}", file=sys.stderr)
        return 2
    sys.path.insert(0, os.path.dirname(path))            # swipe.py imports hookscore from its folder
    spec = importlib.util.spec_from_file_location("ig_tool", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    patched = []
    if hasattr(mod, "WORD_RE"):
        mod.WORD_RE = WORD_RE
        patched.append("WORD_RE")
    if hasattr(mod, "HASHTAG_RE") and mod.HASHTAG_RE.groups == 1:
        mod.HASHTAG_RE = HASHTAG_RE
        patched.append("HASHTAG_RE")
    if not patched:
        print("ar.py: note: this tool has no word pattern to patch; it runs as-is.", file=sys.stderr)
    if os.path.basename(path) == "hookscore.py":
        print("ar.py: note: STAKES/ADDRESS use English word lists; for Arabic hooks score an English gloss.",
              file=sys.stderr)
    if not hasattr(mod, "main"):
        print("ar.py: this file has no main(); is it one of the ig-* tools?", file=sys.stderr)
        return 2
    sys.argv = [path] + sys.argv[2:]
    return mod.main()


if __name__ == "__main__":
    sys.exit(main() or 0)
